Licensing
MyGUI source code (everything in MyGUIEngine folder) licensed under LGPL with with some exclusions:
1. Building against MyGUI headers which have inlined code does not constitute a derived work.
2. Code which subclasses MyGUI classes outside of the MyGUI libraries does not form a derived work.
3. Statically linking the MyGUI libraries into a user application does not make the user application a derived work.

Plugins that based on some library are licensed under same license that librariy use.
All media except some Media pointed below licensed under MIT license.
Everything else (i.e. demos, tools, scripts, configuration files, etc.) is licenses under MIT license.
Licensing for 3rd-party libraries
FreeType

    * Original Authors: David Turner, Robert Wilhelm, and Werner Lemberg
    * Website: http://www.freetype.org
    * Licensed Under: FreeType License

Sample Program Dependencies

These dependencies are only used by our sample programs, and thus you do not need to use them to use MyGUI, if you don't want to.
OGRE

    * Original Authors: Steve Streeting and others (see also http://www.ogre3d.org/index.php?option=com_content&task=view&id=12&Itemid=129)
    * Website: http://www.ogre3d.org
    * Licensed Under: LGPL or MIT or other. See http://www.ogre3d.org/licensing for details.

OIS

    * Original Authors: Phillip Castaneda
    * Website: http://www.wreckedgames.com/wiki/index.php/WreckedLibs:OIS
    * Licensed Under: Zlib License

Acknowledgements
Crystal Clear Items

    * Crystal_Clear_Items, Crystal_Clear_Butterfly and Crystal_Clear_View is based on Crystal Clear icon set.
    * Website: http://www.everaldo.com/crystal/
    * Licensed Under: LGPL

DejaVu fonts

    * DejaVuSans.ttf and DejaVuSans-ExtraLight.ttf are fonts from DejaVu font family.
    * Website: http://dejavu.sourceforge.net/
    * Licensed Under: read http://dejavu.sourceforge.net/wiki/index.php/License

    * Mikki.mesh, Robot.mesh and related files are used by permission of the creator of those models and can be used in MyGUI demos only.
