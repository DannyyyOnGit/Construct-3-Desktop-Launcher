Screenshot Plugin v0.2  by scidave
------------------

Takes snapshots of either the Construct window or the entire desktop.  It stores them in the current path of the running .exe (when using in the Construct GUI look in the temp folder C:\Users\"User name"\AppData\ROaming\Scirra) and auto increments the name of the savefile.

Installation
----------------
Copy the Screenshot.csx into your Scirra/Construct/PLugin directory.  Copy the .csx file in the runtime directory into the Scirra runtime directory.

Use
-------
The plugin is pretty simple as-is and only has one action: take a screenshot.
Set the parameter to 1 for the current Window.
Set it to 0 for the entire desktop.

There is one expression:
GetScreenshotCount: Returns an integer for the current number of screenshots taken.  Can use this to show particular in game screens, etc.   

Enjoy!